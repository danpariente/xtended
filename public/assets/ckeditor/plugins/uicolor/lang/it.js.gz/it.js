/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","it",{uicolor:{title:"Selettore Colore UI",preview:"Anteprima Live",config:"Incolla questa stringa nel tuo file config.js",predefined:"Set di colori predefiniti"}});